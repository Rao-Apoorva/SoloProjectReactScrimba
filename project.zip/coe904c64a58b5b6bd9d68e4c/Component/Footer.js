import React from "react"

export default function Footer()
{
    return (
<>
    <footer>
        <p className="foot">@ALL RIGHT IS RESERVED BY APOORVA</p>
    </footer>
</>
    )
}