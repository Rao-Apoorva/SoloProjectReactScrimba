import React from "react"
export default function Info()
{
    return (
<div>
    <img src="https://img.freepik.com/premium-photo/woman-portrait-park-anime-manga-style_691560-1170.jpg?w=2000" alt="image" width="250px" className="img"/>
    <header className="header">
    <h1 className="name">Apoorva Rao</h1>
    <h3  className="title">Frontend Devopler</h3>
    <h4  className="website">www.raoapoorva.com</h4>
    <button type="button"  className="email">Eamil</button>
    <button type="button"  className="linkedin">LinkedIn</button>
    </header>
</div>
    )
}