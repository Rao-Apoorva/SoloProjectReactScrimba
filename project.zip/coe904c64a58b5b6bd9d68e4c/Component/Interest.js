import React from "react"
export default function Interest()
{
    return(
 <>
    <h2 className="interest">Interest</h2>
    <p className="interestpara">
     Food expert. Music scholar. Reader. Internet fanatic. Bacon buff. Entrepreneur. Travel geek. Pop culture ninja. Coffee fanatic.
    </p>
</>
    )
}